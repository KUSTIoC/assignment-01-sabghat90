package ExamManagmentSystem;

public class Course {

    private final String courseName;
    private String courseCode;
    private final String programName="BS-CS";
    private String semesterCourse;

    public Course(String courseName, String courseCode) {
        this.courseName = courseName;
        this.courseCode = courseCode;
        if(courseCode == "CS-213") {
            semesterCourse = "Spring 2020";
        }
        else if(courseCode == "CS-102") {
            semesterCourse = "Fall 2019";
        }
        else if(courseCode == "BS-121") {
            semesterCourse = "Spring 2020";
        }
    }

    public String getCourseName() {
        return courseName;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public String toString() {
        return String.format("Course Name: %s%nCourse Code: %s%nProgram Name: %s%nSemester Course: %s%n",getCourseName(),getCourseCode(),programName,semesterCourse);
    }
}
