package ExamManagmentSystem;

///////////////////////////////////////////////////////////////////////////
// this is a subclass of Paper class which we used for paper collection
///////////////////////////////////////////////////////////////////////////

public class isCollected extends Paper {
    private String paperID;
    private String courseCode;
    private int numOfStudents;
    private String setIsCollected;

    /* a constructor for subclass */
    public isCollected(String paperTitle, String paperID, String courseCode, String courseIncharge, String semester,
                       String programName, Date paperDate, Time time, String examType, String invigilator, String location,
                       int numOfStudents, String paperID1, String courseCode1, int numOfStudents1, boolean isCollected) {

        /* this is a superclass call */
        super(paperTitle, paperID, courseCode, courseIncharge, semester, programName, paperDate, time, examType, invigilator,
                location, numOfStudents);
        this.paperID = paperID1;
        this.courseCode = courseCode1;
        this.numOfStudents = numOfStudents1;
        /* this condition will check paper collection which is boolean */
        if(isCollected) {
            setIsCollected = "Paper Is Collected";
        }
        else {
            setIsCollected = "Paper isn't collected yet";
        }
    }

    public String getCollected() {
        return setIsCollected;
    }

    public String getPaperID() {
        return paperID;
    }

    public void setPaperID(String paperID) {
        this.paperID = paperID;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public int getNumOfStudents() {
        return numOfStudents;
    }

    public void setNumOfStudents(int numOfStudents) {
        this.numOfStudents = numOfStudents;
    }

    public String isCollected() {
        return setIsCollected;
    }
    /* a set method for paper collection checking */
    public void setCollected(boolean isCollected) {
        if(isCollected) {
            setIsCollected = "Paper Is Collected";
        }
        else {
            setIsCollected = "Paper isn't Collected Yet";
        }
    }

    public String toString() {
        return String.format("Paper ID: %s%nCourse Code: %s%nNumber of student: %d%nPaper Status: %s",
                getPaperID(),getCourseCode(),getNumOfStudents(),isCollected());
    }
}
